module Lab_4 {
	requires java.desktop;
}